import java.util.*;
import java.util.stream.Collectors;

public class ClothingStoreCatalog {

    static final double DISCOUNT = 0.20;
    static final List<String> CATEGORIES = List.of("Shirts", "Pants", "Dresses", "Jackets", "Footwear", "Accessories");
    static final List<String> SIZES = List.of("XS", "S", "M", "L", "XL", "XXL", "Free size");

    static class Item {
        int id;
        String name, category, size, color;
        double price;
        int stock;
        boolean clearance;

        Item(int id, String name, String category, String size, String color,
             double price, int stock, boolean clearance) {
            this.id = id; this.name = name; this.category = category; this.size = size;
            this.color = color; this.price = price; this.stock = stock; this.clearance = clearance;
        }

        double effectivePrice() {
            return clearance ? Math.round(price * (1 - DISCOUNT) * 100.0) / 100.0 : price;
        }

        String priceDisplay() {
            return clearance
                ? String.format("Rs.%.2f (was Rs.%.2f)", effectivePrice(), price)
                : String.format("Rs.%.2f", price);
        }
    }

    static final List<Item> items = new ArrayList<>();
    static int nextId = 1;
    static final Scanner in = new Scanner(System.in);

    // ---------------- input helpers ----------------
    static String readText(String label) {
        while (true) {
            System.out.print(label);
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("  Input cannot be empty.");
        }
    }

    static double readPrice(String label) {
        while (true) {
            System.out.print(label);
            try {
                double d = Double.parseDouble(in.nextLine().trim());
                if (d >= 0) return d;
            } catch (NumberFormatException ignored) { }
            System.out.println("  Enter a valid price (0 or more).");
        }
    }

    static int readInt(String label, int min) {
        while (true) {
            System.out.print(label);
            try {
                int n = Integer.parseInt(in.nextLine().trim());
                if (n >= min) return n;
            } catch (NumberFormatException ignored) { }
            System.out.println("  Enter a whole number (" + min + " or more).");
        }
    }

    static String choose(String label, List<String> options) {
        while (true) {
            System.out.println(label);
            for (int i = 0; i < options.size(); i++) System.out.println("  " + (i + 1) + ". " + options.get(i));
            int n = readInt("  Choice: ", 1);
            if (n <= options.size()) return options.get(n - 1);
            System.out.println("  Pick a number from the list.");
        }
    }

    static boolean readYesNo(String label) {
        while (true) {
            System.out.print(label + " (y/n): ");
            String s = in.nextLine().trim().toLowerCase();
            if (s.equals("y")) return true;
            if (s.equals("n")) return false;
            System.out.println("  Type y or n.");
        }
    }

    static Item findById(int id) {
        return items.stream().filter(i -> i.id == id).findFirst().orElse(null);
    }

    static Item askItem() {
        int id = readInt("Enter item ID: ", 1);
        Item it = findById(id);
        if (it == null) System.out.println("  No item found with ID " + id + ".");
        return it;
    }

    // ---------------- display ----------------
    static void printTable(List<Item> list) {
        if (list.isEmpty()) {
            System.out.println("  No items to show.");
            return;
        }
        String line = "+----+-----------------------+-------------+-----------+---------+-------------------------------+-------+-----------+";
        System.out.println(line);
        System.out.printf("| %-2s | %-21s | %-11s | %-9s | %-7s | %-29s | %-5s | %-9s |%n",
                "ID", "Name", "Category", "Size", "Color", "Price", "Stock", "Status");
        System.out.println(line);
        for (Item i : list) {
            System.out.printf("| %-2d | %-21s | %-11s | %-9s | %-7s | %-29s | %-5d | %-9s |%n",
                    i.id, i.name, i.category, i.size, i.color, i.priceDisplay(), i.stock,
                    i.clearance ? "CLEARANCE" : "Regular");
        }
        System.out.println(line);
    }

    // ---------------- features ----------------
    static void addItem() {
        System.out.println("\n--- Add Item ---");
        String name = readText("Name: ");
        String category = choose("Category:", CATEGORIES);
        String size = choose("Size:", SIZES);
        String color = readText("Color: ");
        double price = readPrice("Price (Rs.): ");
        int stock = readInt("Stock quantity: ", 0);
        boolean clr = readYesNo("Mark as Clearance Sale?");
        items.add(new Item(nextId++, name, category, size, color, price, stock, clr));
        System.out.println("Item added successfully.");
    }

    static void editItem() {
        System.out.println("\n--- Edit Item ---");
        Item it = askItem();
        if (it == null) return;
        System.out.println("Leave blank to keep the current value.");
        System.out.print("Name [" + it.name + "]: ");
        String s = in.nextLine().trim();
        if (!s.isEmpty()) it.name = s;
        if (readYesNo("Change category (current: " + it.category + ")?")) it.category = choose("Category:", CATEGORIES);
        if (readYesNo("Change size (current: " + it.size + ")?")) it.size = choose("Size:", SIZES);
        System.out.print("Color [" + it.color + "]: ");
        s = in.nextLine().trim();
        if (!s.isEmpty()) it.color = s;
        if (readYesNo("Change price (current: Rs." + it.price + ")?")) it.price = readPrice("New price (Rs.): ");
        if (readYesNo("Change stock (current: " + it.stock + ")?")) it.stock = readInt("New stock: ", 0);
        System.out.println("Item updated successfully.");
    }

    static void updateStock() {
        System.out.println("\n--- Update Stock ---");
        Item it = askItem();
        if (it == null) return;
        System.out.println("Current stock of " + it.name + ": " + it.stock);
        it.stock = readInt("New stock quantity: ", 0);
        System.out.println("Stock updated.");
    }

    static void deleteItem() {
        System.out.println("\n--- Delete Item ---");
        Item it = askItem();
        if (it == null) return;
        if (readYesNo("Delete \"" + it.name + "\"?")) {
            items.remove(it);
            System.out.println("Item deleted.");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    static void toggleClearance() {
        System.out.println("\n--- Clearance Sale ---");
        Item it = askItem();
        if (it == null) return;
        it.clearance = !it.clearance;
        if (it.clearance) {
            System.out.println(it.name + " marked as Clearance Sale. New price: " + it.priceDisplay());
        } else {
            System.out.println(it.name + " removed from Clearance Sale. Price: " + it.priceDisplay());
        }
    }

    static void searchFilter() {
        System.out.println("\n--- Search and Filter ---");
        System.out.print("Name or color keyword (blank to skip): ");
        String kw = in.nextLine().trim().toLowerCase();
        String cat = readYesNo("Filter by category?") ? choose("Category:", CATEGORIES) : null;
        String size = readYesNo("Filter by size?") ? choose("Size:", SIZES) : null;
        double max = readYesNo("Filter by maximum price?") ? readPrice("Max price (Rs.): ") : Double.MAX_VALUE;

        List<Item> result = items.stream()
            .filter(i -> kw.isEmpty() || i.name.toLowerCase().contains(kw) || i.color.toLowerCase().contains(kw))
            .filter(i -> cat == null || i.category.equals(cat))
            .filter(i -> size == null || i.size.equals(size))
            .filter(i -> i.effectivePrice() <= max)
            .collect(Collectors.toList());
        System.out.println("\n" + result.size() + " item(s) found:");
        printTable(result);
    }

    static void dashboard() {
        int totalStock = items.stream().mapToInt(i -> i.stock).sum();
        double value = items.stream().mapToDouble(i -> i.effectivePrice() * i.stock).sum();
        long clr = items.stream().filter(i -> i.clearance).count();
        long out = items.stream().filter(i -> i.stock == 0).count();

        System.out.println("\n================ DASHBOARD ================");
        System.out.printf("Total items       : %d%n", items.size());
        System.out.printf("Units in stock    : %d%n", totalStock);
        System.out.printf("Stock value       : Rs.%.2f%n", value);
        System.out.printf("Clearance items   : %d%n", clr);
        System.out.printf("Out of stock      : %d%n", out);

        System.out.println("\nStock by category:");
        int max = 1;
        for (String c : CATEGORIES) {
            max = Math.max(max, items.stream().filter(i -> i.category.equals(c)).mapToInt(i -> i.stock).sum());
        }
        for (String c : CATEGORIES) {
            int s = items.stream().filter(i -> i.category.equals(c)).mapToInt(i -> i.stock).sum();
            int bar = (int) Math.round(s * 25.0 / max);
            System.out.printf("  %-12s %-25s %d%n", c, "#".repeat(bar), s);
        }

        System.out.println("\nLow stock (5 or fewer):");
        List<Item> low = items.stream().filter(i -> i.stock <= 5)
            .sorted(Comparator.comparingInt(i -> i.stock)).collect(Collectors.toList());
        if (low.isEmpty()) System.out.println("  Everything is well stocked.");
        for (Item i : low) System.out.printf("  %-22s (%s) -> %d left%n", i.name, i.size, i.stock);
        System.out.println("===========================================");
    }

    static void seed() {
        items.add(new Item(nextId++, "Oxford Cotton Shirt", "Shirts", "M", "Blue", 1499, 24, false));
        items.add(new Item(nextId++, "Slim Fit Chinos", "Pants", "L", "Beige", 1899, 3, true));
        items.add(new Item(nextId++, "Summer Wrap Dress", "Dresses", "S", "Pink", 2499, 12, true));
        items.add(new Item(nextId++, "Denim Jacket", "Jackets", "XL", "Navy", 3299, 7, false));
        items.add(new Item(nextId++, "Canvas Sneakers", "Footwear", "Free size", "White", 1299, 0, false));
        items.add(new Item(nextId++, "Leather Belt", "Accessories", "Free size", "Brown", 699, 18, false));
    }

    public static void main(String[] args) {
        seed();
        System.out.println("=== Clothing Store Catalog Management ===");
        while (true) {
            System.out.println("\n1. Add item");
            System.out.println("2. View all items");
            System.out.println("3. Edit item");
            System.out.println("4. Update stock");
            System.out.println("5. Delete item");
            System.out.println("6. Mark / unmark Clearance Sale");
            System.out.println("7. Search and filter");
            System.out.println("8. Dashboard");
            System.out.println("0. Exit");
            int choice = readInt("Enter your choice: ", 0);
            switch (choice) {
                case 1 -> addItem();
                case 2 -> { System.out.println(); printTable(items); }
                case 3 -> editItem();
                case 4 -> updateStock();
                case 5 -> deleteItem();
                case 6 -> toggleClearance();
                case 7 -> searchFilter();
                case 8 -> dashboard();
                case 0 -> { System.out.println("Goodbye!"); return; }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
