const API = "/api";
const COLORS = {white:"#f5f5f5",black:"#222",blue:"#2f6fb5",navy:"#1b2a4e",red:"#c0392b",green:"#2e7d4f",grey:"#8a8f98",gray:"#8a8f98",yellow:"#e8c33b",pink:"#e78fb0",brown:"#7b5230",beige:"#d9c5a0",orange:"#e0801f",purple:"#7b4fa6"};
let editId = null;

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = (n) => "₹" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });

async function api(path, method = "GET", body) {
  const res = await fetch(API + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}

function fill(el, arr, first) {
  el.innerHTML = (first !== undefined ? `<option value="">${first}</option>` : "") +
    arr.map((v) => `<option>${esc(v)}</option>`).join("");
}

// ---------- dashboard ----------
async function loadStats() {
  const s = await api("/stats");
  const cards = [
    ["Total items", s.totalItems],
    ["Units in stock", s.totalStock],
    ["Stock value", money(s.stockValue)],
    ["Clearance items", s.clearanceCount, "sale"],
    ["Out of stock", s.outOfStock],
  ];
  $("stats").innerHTML = cards
    .map((c) => `<div class="stat ${c[2] || ""}"><div class="num">${c[1]}</div><span>${c[0]}</span></div>`)
    .join("");
  const mx = Math.max(1, ...s.byCategory.map((b) => b.stock));
  $("chart").innerHTML = s.byCategory
    .map((b) => `<div class="bar"><span>${b.category}</span><i style="width:${(b.stock / mx) * 100}%"></i><span>${b.stock}</span></div>`)
    .join("");
  $("low").innerHTML = s.lowStock.length
    ? s.lowStock.map((i) => `<div class="low"><span>${esc(i.name)} (${esc(i.size)})</span><b>${i.stock}</b></div>`).join("")
    : '<p class="meta">Everything is well stocked.</p>';
}

// ---------- catalog ----------
async function loadItems() {
  const p = new URLSearchParams({
    q: $("q").value.trim(),
    category: $("fc").value,
    size: $("fs").value,
    status: $("fx").value,
    maxPrice: $("fp").value,
  });
  const items = await api("/items?" + p.toString());
  $("list").innerHTML = items.length
    ? items.map((i) => {
        const hex = COLORS[i.color.toLowerCase()] || "#cfc9c0";
        return `<article class="card">
          <div class="swatch" style="background:${hex}">${i.clearance ? '<span class="tag">Clearance −20%</span>' : ""}</div>
          <div class="body">
            <h3>${esc(i.name)}</h3>
            <div class="meta">${esc(i.category)} · Size ${esc(i.size)} · ${esc(i.color)}</div>
            <div class="price ${i.clearance ? "on" : ""}">${money(i.clearance ? i.salePrice : i.price)}${i.clearance ? `<s>${money(i.price)}</s>` : ""}</div>
            <div class="stock ${i.stock === 0 ? "out" : ""}">${i.stock === 0 ? "Out of stock" : i.stock + " in stock"}</div>
          </div>
          <div class="acts">
            <button class="btn" data-a="edit" data-id="${i.id}">Edit</button>
            <button class="btn" data-a="stock" data-id="${i.id}" data-stock="${i.stock}" data-name="${esc(i.name)}">Update stock</button>
            <button class="btn" data-a="clr" data-id="${i.id}">${i.clearance ? "Remove clearance" : "Mark clearance"}</button>
            <button class="btn danger" data-a="del" data-id="${i.id}" data-name="${esc(i.name)}">Delete</button>
          </div></article>`;
      }).join("")
    : '<div class="empty">No items match. Clear the filters or add a new item.</div>';
}

const refresh = () => Promise.all([loadStats(), loadItems()]).catch((e) => alert(e.message));

// ---------- form ----------
async function openForm(id) {
  editId = id || null;
  $("dt").textContent = id ? "Edit item" : "Add item";
  $("err").textContent = "";
  let i = { name: "", category: $("c").options[0].value, size: "Free size", color: "", price: "", stock: "", clearance: false };
  if (id) i = await api("/items/" + id);
  $("n").value = i.name; $("c").value = i.category; $("s").value = i.size;
  $("co").value = i.color; $("p").value = i.price; $("st").value = i.stock; $("cl").checked = i.clearance;
  $("dlg").showModal();
  $("n").focus();
}

async function save() {
  const body = {
    name: $("n").value, category: $("c").value, size: $("s").value, color: $("co").value,
    price: $("p").value, stock: $("st").value, clearance: $("cl").checked,
  };
  try {
    if (editId) await api("/items/" + editId, "PUT", body);
    else await api("/items", "POST", body);
    $("dlg").close();
    refresh();
  } catch (e) {
    $("err").textContent = e.message;
  }
}

// ---------- events ----------
$("add").onclick = () => openForm();
$("save").onclick = save;
$("cancel").onclick = () => $("dlg").close();
$("theme").onclick = () => {
  const r = document.documentElement;
  const dark = r.dataset.theme ? r.dataset.theme === "dark" : matchMedia("(prefers-color-scheme:dark)").matches;
  r.dataset.theme = dark ? "light" : "dark";
};
$("reset").onclick = () => { ["q", "fc", "fs", "fx", "fp"].forEach((k) => ($(k).value = "")); loadItems(); };
["q", "fc", "fs", "fx", "fp"].forEach((k) => $(k).addEventListener("input", loadItems));

$("list").onclick = async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const id = b.dataset.id;
  try {
    if (b.dataset.a === "edit") openForm(id);
    else if (b.dataset.a === "clr") { await api(`/items/${id}/clearance`, "PATCH", {}); refresh(); }
    else if (b.dataset.a === "stock") {
      const v = prompt("New stock quantity for " + b.dataset.name, b.dataset.stock);
      if (v !== null) { await api(`/items/${id}/stock`, "PATCH", { stock: Number(v) }); refresh(); }
    } else if (b.dataset.a === "del") {
      if (confirm("Delete " + b.dataset.name + "?")) { await api("/items/" + id, "DELETE"); refresh(); }
    }
  } catch (err) { alert(err.message); }
};

// ---------- init ----------
(async () => {
  const meta = await api("/meta");
  fill($("c"), meta.categories);
  fill($("s"), meta.sizes);
  fill($("fc"), meta.categories, "All categories");
  fill($("fs"), meta.sizes, "All sizes");
  refresh();
})();
