const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const FILE = path.join(__dirname, "data", "products.json");
const DISCOUNT = 0.2; // 20% clearance discount

const CATEGORIES = ["Shirts", "Pants", "Dresses", "Jackets", "Footwear", "Accessories"];
const SIZES = ["XS", "S", "M", "L", "XL", "XXL", "Free size"];

app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));

// ---------- helpers ----------
const read = () => JSON.parse(fs.readFileSync(FILE, "utf8"));
const write = (data) => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));

const withPrice = (i) => ({
  ...i,
  salePrice: i.clearance ? +(i.price * (1 - DISCOUNT)).toFixed(2) : null,
});
const effective = (i) => (i.clearance ? i.price * (1 - DISCOUNT) : i.price);

function validate(b) {
  const name = String(b.name || "").trim();
  const color = String(b.color || "").trim();
  const price = Number(b.price);
  const stock = Number(b.stock);
  if (!name) return { error: "Name is required." };
  if (!color) return { error: "Color is required." };
  if (!CATEGORIES.includes(b.category)) return { error: "Invalid category." };
  if (!SIZES.includes(b.size)) return { error: "Invalid size." };
  if (!Number.isFinite(price) || price < 0) return { error: "Price must be 0 or more." };
  if (!Number.isInteger(stock) || stock < 0) return { error: "Stock must be a whole number, 0 or more." };
  return {
    data: { name, category: b.category, size: b.size, color, price, stock, clearance: !!b.clearance },
  };
}

// ---------- routes ----------
app.get("/api/meta", (req, res) => res.json({ categories: CATEGORIES, sizes: SIZES, discount: DISCOUNT }));

// List + search + filter
app.get("/api/items", (req, res) => {
  const { q, category, size, status, maxPrice } = req.query;
  let items = read();
  if (q) {
    const s = q.toLowerCase();
    items = items.filter((i) => i.name.toLowerCase().includes(s) || i.color.toLowerCase().includes(s));
  }
  if (category) items = items.filter((i) => i.category === category);
  if (size) items = items.filter((i) => i.size === size);
  if (status === "sale") items = items.filter((i) => i.clearance);
  if (status === "reg") items = items.filter((i) => !i.clearance);
  if (maxPrice !== undefined && maxPrice !== "" && !isNaN(maxPrice))
    items = items.filter((i) => effective(i) <= Number(maxPrice));
  res.json(items.map(withPrice));
});

// View one
app.get("/api/items/:id", (req, res) => {
  const item = read().find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ error: "Item not found." });
  res.json(withPrice(item));
});

// Add
app.post("/api/items", (req, res) => {
  const { data, error } = validate(req.body);
  if (error) return res.status(400).json({ error });
  const items = read();
  const id = items.reduce((m, i) => Math.max(m, i.id), 0) + 1;
  const item = { id, ...data };
  items.push(item);
  write(items);
  res.status(201).json(withPrice(item));
});

// Edit
app.put("/api/items/:id", (req, res) => {
  const { data, error } = validate(req.body);
  if (error) return res.status(400).json({ error });
  const items = read();
  const idx = items.findIndex((i) => i.id === Number(req.params.id));
  if (idx < 0) return res.status(404).json({ error: "Item not found." });
  items[idx] = { id: items[idx].id, ...data };
  write(items);
  res.json(withPrice(items[idx]));
});

// Update stock only
app.patch("/api/items/:id/stock", (req, res) => {
  const stock = Number(req.body.stock);
  if (!Number.isInteger(stock) || stock < 0)
    return res.status(400).json({ error: "Stock must be a whole number, 0 or more." });
  const items = read();
  const item = items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ error: "Item not found." });
  item.stock = stock;
  write(items);
  res.json(withPrice(item));
});

// Toggle clearance
app.patch("/api/items/:id/clearance", (req, res) => {
  const items = read();
  const item = items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ error: "Item not found." });
  item.clearance = typeof req.body.clearance === "boolean" ? req.body.clearance : !item.clearance;
  write(items);
  res.json(withPrice(item));
});

// Delete
app.delete("/api/items/:id", (req, res) => {
  const items = read();
  const idx = items.findIndex((i) => i.id === Number(req.params.id));
  if (idx < 0) return res.status(404).json({ error: "Item not found." });
  const [removed] = items.splice(idx, 1);
  write(items);
  res.json({ deleted: removed.id });
});

// Dashboard stats
app.get("/api/stats", (req, res) => {
  const items = read();
  res.json({
    totalItems: items.length,
    totalStock: items.reduce((a, i) => a + i.stock, 0),
    stockValue: +items.reduce((a, i) => a + effective(i) * i.stock, 0).toFixed(2),
    clearanceCount: items.filter((i) => i.clearance).length,
    outOfStock: items.filter((i) => i.stock === 0).length,
    byCategory: CATEGORIES.map((c) => ({
      category: c,
      stock: items.filter((i) => i.category === c).reduce((a, i) => a + i.stock, 0),
    })),
    lowStock: items
      .filter((i) => i.stock <= 5)
      .sort((a, b) => a.stock - b.stock)
      .map((i) => ({ id: i.id, name: i.name, size: i.size, stock: i.stock })),
  });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
